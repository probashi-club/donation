import { useEffect, useState } from 'react';
import {
  ArrowDown,
  BookOpen,
  Check,
  Heart,
  Lock,
  Share2,
  ShieldCheck,
} from 'lucide-react';
import {
  CAMPAIGN_COPY,
  CAMPAIGN_SETTINGS,
  CommentItem,
  toBanglaDigits,
} from './data/campaignContent';
import { DonationModal } from './components/DonationModal';
import { FaqSection } from './components/FaqSection';
import { CommentsSection } from './components/CommentsSection';
import studyDeskImg from './assets/images/study_desk_preparation_1794596201888.jpg';
import campusDawnImg from './assets/images/bangladesh_campus_dawn_1794596201795.jpg';

const HERO_BANNER_SRC =
  './assets/aistudio/file_0000000031088246b3bdea448b4baa45_cleaned_bd037cab.png';
const COMMENTS_STORAGE_KEY = 'swapnojatra_comments_v1';

export default function App() {
  const [donationOpen, setDonationOpen] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [deskImgFailed, setDeskImgFailed] = useState(false);
  const [campusImgFailed, setCampusImgFailed] = useState(false);

  const [comments, setComments] = useState<CommentItem[]>(() => {
    try {
      const saved = localStorage.getItem(COMMENTS_STORAGE_KEY);
      return saved ? (JSON.parse(saved) as CommentItem[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(COMMENTS_STORAGE_KEY, JSON.stringify(comments));
    } catch {
      // Ignore storage quota errors
    }
  }, [comments]);

  function handleAddComment(
    authorName: string,
    message: string,
    location?: string,
  ) {
    const newComment: CommentItem = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      authorName,
      location,
      message,
      createdAtIso: new Date().toISOString(),
    };
    setComments((prev) => [newComment, ...prev].slice(0, 60));
  }

  async function handleShareLink() {
    const shareUrl = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: CAMPAIGN_COPY.title,
          text: CAMPAIGN_COPY.sectionTitle,
          url: shareUrl,
        });
        return;
      } catch {
        // Fall through to clipboard copy
      }
    }
    try {
      await navigator.clipboard.writeText(shareUrl);
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2200);
    } catch {
      // Ignore if clipboard blocked
    }
  }

  const progressPercent = Math.min(
    100,
    Math.max(0, CAMPAIGN_SETTINGS.progressPercent),
  );

  return (
    <div className="min-h-screen bg-[#FAFAF8] text-[#141917]">
      {/* 3-Zone Top Bar */}
      <header className="sticky top-0 z-40 border-b border-[#E6E4DF] bg-[#FAFAF8]/95 backdrop-blur-sm">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-8 px-5 sm:px-8">
          {/* Zone 1: Single-element brand wordmark */}
          <a
            href="#"
            className="font-display text-xl font-bold tracking-tight text-[#0F5C43] whitespace-nowrap shrink-0"
          >
            {CAMPAIGN_COPY.brand}
          </a>

          {/* Zone 2: 4 concise single-line nav links */}
          <nav
            aria-label="প্রধান মেনু"
            className="hidden items-center gap-7 text-sm font-medium text-[#4A524E] md:flex"
          >
            <a
              href="#story"
              className="transition-colors duration-150 hover:text-[#141917] whitespace-nowrap shrink-0"
            >
              আবেদন
            </a>
            <a
              href="#privacy"
              className="transition-colors duration-150 hover:text-[#141917] whitespace-nowrap shrink-0"
            >
              স্বচ্ছতা
            </a>
            <a
              href="#faq"
              className="transition-colors duration-150 hover:text-[#141917] whitespace-nowrap shrink-0"
            >
              জিজ্ঞাসা
            </a>
            <a
              href="#comments"
              className="transition-colors duration-150 hover:text-[#141917] whitespace-nowrap shrink-0"
            >
              মন্তব্য
            </a>
          </nav>

          {/* Zone 3: 1 primary CTA */}
          <div className="shrink-0">
            <button
              type="button"
              onClick={() => setDonationOpen(true)}
              className="inline-flex min-h-[42px] items-center gap-2 rounded-xl bg-[#0F5C43] px-4 py-2 text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#0B4733] whitespace-nowrap shrink-0"
            >
              <Heart className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>সহযোগিতা করুন</span>
            </button>
          </div>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="py-10 sm:py-16 lg:py-20">
          <div className="mx-auto max-w-6xl px-5 sm:px-8">
            <div className="grid grid-cols-1 items-stretch gap-8 lg:grid-cols-12 lg:gap-12">
              <div className="flex flex-col justify-center lg:col-span-6">
                <p className="text-xs font-medium text-[#0F5C43] sm:text-sm">
                  {CAMPAIGN_COPY.kicker}
                </p>

                <h1 className="mt-3 font-display text-[clamp(2rem,4vw,3.25rem)] font-bold leading-[1.18] tracking-tight text-[#141917] text-balance">
                  {CAMPAIGN_COPY.title}{' '}
                  <Heart
                    className="mb-1 inline-block h-7 w-7 fill-[#C81E32] text-[#C81E32] sm:h-9 sm:w-9"
                    aria-label="ভালোবাসার প্রতীক"
                  />
                </h1>

                <p className="mt-4 max-w-xl text-base leading-[1.7] text-[#4A524E] sm:text-lg">
                  {CAMPAIGN_COPY.sectionTitle}
                </p>

                <div className="mt-7 flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setDonationOpen(true)}
                    className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-[#0F5C43] px-6 py-3 text-base font-semibold text-white transition-colors duration-150 hover:bg-[#0B4733] whitespace-nowrap shrink-0"
                  >
                    <Heart className="h-4 w-4 shrink-0" aria-hidden="true" />
                    <span>ডোনেশন পাঠান</span>
                  </button>

                  <a
                    href="#story"
                    className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-[#D8D5CE] bg-white px-5 py-3 text-sm font-semibold text-[#141917] transition-colors duration-150 hover:bg-[#F3F1EC] whitespace-nowrap shrink-0"
                  >
                    <span>বিস্তারিত পড়ুন</span>
                    <ArrowDown className="h-4 w-4 shrink-0" aria-hidden="true" />
                  </a>

                  <button
                    type="button"
                    onClick={handleShareLink}
                    className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-medium text-[#4A524E] transition-colors duration-150 hover:bg-[#F3F1EC] hover:text-[#141917] whitespace-nowrap shrink-0"
                  >
                    {linkCopied ? (
                      <>
                        <Check
                          className="h-4 w-4 text-[#0F5C43]"
                          aria-hidden="true"
                        />
                        <span className="text-[#0F5C43]">লিংক কপি হয়েছে</span>
                      </>
                    ) : (
                      <>
                        <Share2 className="h-4 w-4 shrink-0" aria-hidden="true" />
                        <span>শেয়ার করুন</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="lg:col-span-6">
                <div className="h-full overflow-hidden rounded-2xl border border-[#E6E4DF] bg-white">
                  {!heroImgFailed ? (
                    <img
                      src={HERO_BANNER_SRC}
                      alt="প্রবাসী ভাইদের ভালোবাসায় এগিয়ে যাক আমার স্বপ্ন — পাশে থাকুন, স্বপ্ন পূরণে সহযোগিতা করুন"
                      referrerPolicy="no-referrer"
                      onError={() => setHeroImgFailed(true)}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="flex aspect-[3/2] h-full w-full flex-col items-center justify-center bg-gradient-to-br from-[#EEF7F2] to-[#F3F1EC] p-8 text-center">
                      <BookOpen
                        className="h-10 w-10 text-[#0F5C43]"
                        aria-hidden="true"
                      />
                      <p className="mt-3 font-display text-lg font-bold text-[#141917]">
                        {CAMPAIGN_COPY.title}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Percentage-Only Progress Tracker (Zero Money Amounts Displayed) */}
            <div className="mt-10 rounded-2xl border border-[#E6E4DF] bg-white p-6 sm:p-8">
              <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
                <div>
                  <p className="text-xs font-medium text-[#0F5C43] sm:text-sm">
                    সহযোগিতা অগ্রগতি (টার্গেটের শতাংশ)
                  </p>
                  <h2 className="mt-1 font-display text-xl font-bold text-[#141917] sm:text-2xl">
                    {CAMPAIGN_SETTINGS.statusNote}
                  </h2>
                </div>
                <div className="flex items-baseline gap-2 sm:text-right">
                  <span className="font-mono text-3xl font-bold text-[#0F5C43] tabular-nums sm:text-4xl">
                    {toBanglaDigits(progressPercent)}%
                  </span>
                  <span className="text-sm font-medium text-[#4A524E]">
                    সম্পন্ন হয়েছে
                  </span>
                </div>
              </div>

              <div
                className="mt-5 h-3.5 w-full overflow-hidden rounded-full bg-[#ECEAE4]"
                role="progressbar"
                aria-valuenow={progressPercent}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label="ডোনেশন লক্ষ্যমাত্রার শতাংশ অগ্রগতি"
              >
                <div
                  className="h-full origin-left rounded-full bg-[#0F5C43] transition-transform duration-500 ease-out"
                  style={{
                    transform: `scaleX(${Math.max(0.015, progressPercent / 100)})`,
                  }}
                />
              </div>

              <div className="mt-2 flex justify-between font-mono text-xs text-[#6B736F] tabular-nums">
                <span>০%</span>
                <span>২৫%</span>
                <span>৫০%</span>
                <span>৭৫%</span>
                <span>১০০%</span>
              </div>

              {/* 4-Column Editorial Context Strip */}
              <div className="mt-8 grid grid-cols-1 gap-6 border-t border-[#E6E4DF] pt-6 sm:grid-cols-2 lg:grid-cols-4">
                <div>
                  <p className="text-xs font-medium text-[#6B736F]">
                    শিক্ষাগত যোগ্যতা
                  </p>
                  <p className="mt-1 text-sm font-semibold text-[#141917]">
                    দুজনেই পাবলিক বিশ্ববিদ্যালয় থেকে মাস্টার্স সম্পন্ন
                  </p>
                </div>
                <div>
                  <p className="text-xs font-medium text-[#6B736F]">মূল লক্ষ্য</p>
                  <p className="mt-1 text-sm font-semibold text-[#141917]">
                    বিসিএস ও সরকারি চাকরির মাধ্যমে স্বাবলম্বী হওয়া
                  </p>
                </div>
                <div>
                  <p className="text-xs font-medium text-[#6B736F]">
                    সহযোগিতার ধরন
                  </p>
                  <p className="mt-1 text-sm font-semibold text-[#141917]">
                    ৫০, ১০০, ২০০ বা ৫০০ টাকা—সাধ্যমতো যেকোনো সহায়তা
                  </p>
                </div>
                <div>
                  <p className="text-xs font-medium text-[#6B736F]">
                    সত্যতা যাচাই
                  </p>
                  <p className="mt-1 text-sm font-semibold text-[#141917]">
                    ব্যক্তিগতভাবে শিক্ষাগত সনদ ও হিসাব প্রদানে প্রস্তুত
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Main Appeal & Story Section */}
        <section
          id="story"
          className="border-t border-[#E6E4DF] bg-white py-16 md:py-24"
        >
          <div className="mx-auto max-w-6xl px-5 sm:px-8">
            <div className="grid grid-cols-1 items-start gap-10 lg:grid-cols-12 lg:gap-14">
              {/* Main Letter Prose */}
              <div className="lg:col-span-7">
                <p className="text-sm font-medium text-[#0F5C43]">
                  আমাদের গল্প ও বাস্তবতা
                </p>
                <h2 className="mt-2 font-display text-2xl font-bold leading-snug tracking-tight text-[#141917] sm:text-3xl text-balance">
                  {CAMPAIGN_COPY.sectionTitle}
                </h2>

                <div className="mt-7 space-y-5 text-[16px] leading-[1.85] text-[#2F3633] sm:text-[17px]">
                  {CAMPAIGN_COPY.mainParagraphs.map((paragraph, idx) => (
                    <p key={idx}>{paragraph}</p>
                  ))}
                </div>

                <div className="mt-8">
                  <button
                    type="button"
                    onClick={() => setDonationOpen(true)}
                    className="inline-flex min-h-[46px] items-center gap-2 rounded-xl bg-[#0F5C43] px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#0B4733] whitespace-nowrap"
                  >
                    <Heart className="h-4 w-4 shrink-0" aria-hidden="true" />
                    <span>এখনই সহযোগিতা করুন</span>
                  </button>
                </div>
              </div>

              {/* Right Column: Study Image & Privacy Highlight */}
              <div className="space-y-8 lg:col-span-5">
                <figure className="overflow-hidden rounded-2xl border border-[#E6E4DF] bg-[#FAFAF8]">
                  {!deskImgFailed ? (
                    <img
                      src={studyDeskImg}
                      alt="বিসিএস ও সরকারি চাকরির প্রস্তুতির পড়ার টেবিল ও বই"
                      referrerPolicy="no-referrer"
                      onError={() => setDeskImgFailed(true)}
                      className="aspect-[4/3] w-full object-cover"
                    />
                  ) : (
                    <div className="flex aspect-[4/3] w-full items-center justify-center bg-[#F3F1EC]">
                      <BookOpen className="h-10 w-10 text-[#0F5C43]" />
                    </div>
                  )}
                  <figcaption className="border-t border-[#E6E4DF] px-4 py-3 text-xs text-[#4A524E]">
                    পরিশ্রম ও প্রস্তুতি চালিয়ে যাওয়ার প্রচেষ্টা — বই, নোটস ও
                    সম্মানজনক ভবিষ্যতের স্বপ্ন
                  </figcaption>
                </figure>

                {/* Highlight: Identity Privacy Request */}
                <div
                  id="privacy"
                  className="rounded-2xl border border-[#E6E4DF] bg-[#F3F1EC] p-6 sm:p-7"
                >
                  <div className="flex items-center gap-2.5 text-[#0F5C43]">
                    <Lock className="h-5 w-5 shrink-0" aria-hidden="true" />
                    <h3 className="font-display text-lg font-bold text-[#141917] sm:text-xl">
                      {CAMPAIGN_COPY.highlightTitle}
                    </h3>
                  </div>

                  <div className="mt-4 space-y-4 text-[15px] leading-[1.8] text-[#2F3633]">
                    {CAMPAIGN_COPY.highlightParagraphs.map((para, idx) => (
                      <p key={idx}>{para}</p>
                    ))}
                  </div>

                  <div className="mt-5 flex items-center gap-2 border-t border-[#DDDAD2] pt-4 text-xs font-medium text-[#0F5C43]">
                    <ShieldCheck className="h-4 w-4 shrink-0" aria-hidden="true" />
                    <span>
                      বিশ্বস্ততা ও সত্যতা যাচাইয়ের জন্য ব্যক্তিগতভাবে সনদ প্রদানযোগ্য
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Closing Emotional Appeal Banner with Campus Dawn Image */}
        <section className="relative overflow-hidden border-t border-[#E6E4DF] bg-[#141917] text-white">
          {!campusImgFailed && (
            <img
              src={campusDawnImg}
              alt="বাংলাদেশের পাবলিক বিশ্ববিদ্যালয়ের ভোরের আলো ও আশার প্রতীক"
              referrerPolicy="no-referrer"
              onError={() => setCampusImgFailed(true)}
              className="absolute inset-0 h-full w-full object-cover opacity-40"
            />
          )}
          <div
            className="absolute inset-0 bg-gradient-to-r from-[#0B1C16]/90 via-[#0B1C16]/80 to-[#0B1C16]/70"
            aria-hidden="true"
          />

          <div className="relative mx-auto max-w-4xl px-5 py-16 text-center sm:px-8 sm:py-24">
            <h2 className="font-display text-2xl font-bold leading-snug tracking-wide text-white sm:text-4xl text-balance">
              {CAMPAIGN_COPY.lastTopic}{' '}
              <Heart
                className="mb-1 inline-block h-7 w-7 fill-[#E13B4F] text-[#E13B4F]"
                aria-hidden="true"
              />
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-[#D8E2DD] sm:text-base">
              আজ আপনার সামান্য সহানুভূতি হয়তো দুটি মানুষের সারা জীবনের
              স্বনির্ভরতার ভিত্তি গড়ে দেবে।
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
              <button
                type="button"
                onClick={() => setDonationOpen(true)}
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-white px-7 py-3 text-base font-bold text-[#0F5C43] transition-colors duration-150 hover:bg-[#F3F1EC] whitespace-nowrap"
              >
                <Heart className="h-4 w-4 fill-[#C81E32] text-[#C81E32]" />
                <span>সহযোগিতা করুন (বিকাশ / নগদ)</span>
              </button>
              <button
                type="button"
                onClick={handleShareLink}
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-white/30 bg-white/10 px-6 py-3 text-sm font-semibold text-white transition-colors duration-150 hover:bg-white/20 whitespace-nowrap"
              >
                <Share2 className="h-4 w-4" />
                <span>
                  {linkCopied ? 'লিংক কপি হয়েছে' : 'লিংকটি শেয়ার করুন'}
                </span>
              </button>
            </div>
          </div>
        </section>

        {/* FAQ Section (All 10 Questions) */}
        <FaqSection />

        {/* Comments Section */}
        <CommentsSection
          comments={comments}
          onAddComment={handleAddComment}
        />
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-[#E6E4DF] bg-white py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 px-5 sm:flex-row sm:items-center sm:px-8">
          <div>
            <span className="font-display text-lg font-bold text-[#0F5C43]">
              {CAMPAIGN_COPY.brand}
            </span>
            <p className="mt-1 text-xs text-[#4A524E]">
              ব্যক্তিগত গোপনীয়তা বজায় রেখে শিক্ষা ও স্বনির্ভরতার পথে মানবিক
              সহায়তা আবেদন।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-[#4A524E]">
            <a href="#story" className="hover:text-[#141917] whitespace-nowrap">
              আবেদন
            </a>
            <a
              href="#privacy"
              className="hover:text-[#141917] whitespace-nowrap"
            >
              স্বচ্ছতা
            </a>
            <a href="#faq" className="hover:text-[#141917] whitespace-nowrap">
              জিজ্ঞাসা
            </a>
            <a
              href="#comments"
              className="hover:text-[#141917] whitespace-nowrap"
            >
              মন্তব্য
            </a>
          </div>
        </div>
      </footer>

      {/* Donation Modal */}
      <DonationModal
        open={donationOpen}
        onClose={() => setDonationOpen(false)}
        campaign={CAMPAIGN_SETTINGS}
        onCommentAdded={(authorName, msg) => handleAddComment(authorName, msg)}
      />
    </div>
  );
}
