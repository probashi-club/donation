export function BkashLogo({ className = 'h-8 w-auto' }: { className?: string }) {
  return (
    <div className={`inline-flex items-center gap-2 ${className}`}>
      <svg
        viewBox="0 0 40 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="h-8 w-8 shrink-0"
        aria-hidden="true"
      >
        <rect width="40" height="40" rx="10" fill="#E2136E" />
        <path
          d="M11 12.5L22.2 10L18.6 19.8L11 12.5Z"
          fill="#FFFFFF"
        />
        <path
          d="M22.2 10L29.5 18.2L21.4 20.6L18.6 19.8L22.2 10Z"
          fill="#FFD1E6"
        />
        <path
          d="M18.6 19.8L29.5 18.2L22.8 29.8L16.5 25.5L18.6 19.8Z"
          fill="#FFFFFF"
        />
        <path
          d="M16.5 25.5L11.2 28.5L14.8 21.8L18.6 19.8L16.5 25.5Z"
          fill="#F9B4D2"
        />
      </svg>
      <div className="flex flex-col leading-none">
        <span className="font-display text-base font-bold text-[#E2136E]">
          বিকাশ
        </span>
        <span className="text-[11px] font-semibold tracking-tight text-[#4A524E]">
          bKash
        </span>
      </div>
    </div>
  );
}

export function NagadLogo({ className = 'h-8 w-auto' }: { className?: string }) {
  return (
    <div className={`inline-flex items-center gap-2 ${className}`}>
      <svg
        viewBox="0 0 40 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="h-8 w-8 shrink-0"
        aria-hidden="true"
      >
        <rect width="40" height="40" rx="10" fill="#F26522" />
        <circle cx="20" cy="20" r="11" fill="#FFFFFF" />
        <path
          d="M15.2 25.2V14.8H18.1L22.7 21.2V14.8H25.2V25.2H22.4L17.7 18.7V25.2H15.2Z"
          fill="#ED1C24"
        />
      </svg>
      <div className="flex flex-col leading-none">
        <span className="font-display text-base font-bold text-[#D94E14]">
          নগদ
        </span>
        <span className="text-[11px] font-semibold tracking-tight text-[#4A524E]">
          Nagad
        </span>
      </div>
    </div>
  );
}
