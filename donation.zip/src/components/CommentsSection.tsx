import { FormEvent, useState } from 'react';
import { MessageSquareHeart, Send } from 'lucide-react';
import {
  CommentItem,
  formatBanglaDate,
  toBanglaDigits,
} from '../data/campaignContent';

interface CommentsSectionProps {
  comments: CommentItem[];
  onAddComment: (
    authorName: string,
    message: string,
    location?: string,
  ) => void;
}

export function CommentsSection({
  comments,
  onAddComment,
}: CommentsSectionProps) {
  const [authorName, setAuthorName] = useState('');
  const [location, setLocation] = useState('');
  const [message, setMessage] = useState('');
  const [submitFeedback, setSubmitFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSubmitFeedback(null);

    const cleanName = authorName.trim().slice(0, 60);
    const cleanLocation = location.trim().slice(0, 50);
    const cleanMessage = message.trim().slice(0, 500);

    if (!cleanName) {
      setSubmitFeedback({
        type: 'error',
        text: 'অনুগ্রহ করে আপনার নাম লিখুন।',
      });
      return;
    }

    if (cleanMessage.length < 2) {
      setSubmitFeedback({
        type: 'error',
        text: 'অনুগ্রহ করে একটি অর্থবহ মন্তব্য বা দোয়া লিখুন।',
      });
      return;
    }

    onAddComment(cleanName, cleanMessage, cleanLocation || undefined);
    setAuthorName('');
    setLocation('');
    setMessage('');
    setSubmitFeedback({
      type: 'success',
      text: 'আপনার মন্তব্যটি যুক্ত হয়েছে। পাশে থাকার জন্য কৃতজ্ঞতা।',
    });
  }

  return (
    <section
      id="comments"
      className="border-t border-[#E6E4DF] bg-[#FAFAF8] py-16 md:py-24"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Left: Form */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl border border-[#E6E4DF] bg-white p-6 sm:p-8">
              <p className="text-sm font-medium text-[#0F5C43]">
                সহমর্মিতা ও ভালোবাসা
              </p>
              <h2 className="mt-2 font-display text-2xl font-bold tracking-tight text-[#141917] text-balance">
                আপনার মন্তব্য বা দোয়া লিখুন
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-[#4A524E]">
                অনুদান দিতে না পারলেও আপনার একটি দোয়া বা উৎসাহমূলক কথা আমাদের
                অনেক সাহস জোগাবে।
              </p>

              <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                <div>
                  <label
                    htmlFor="comment-name"
                    className="mb-1.5 block text-sm font-medium text-[#141917]"
                  >
                    আপনার নাম <span className="text-[#C81E32]">*</span>
                  </label>
                  <input
                    id="comment-name"
                    type="text"
                    maxLength={60}
                    required
                    value={authorName}
                    onChange={(e) => setAuthorName(e.target.value)}
                    placeholder="যেমন: মো. আরিফুর রহমান বা একজন শুভাকাঙ্ক্ষী"
                    className="min-h-[44px] w-full rounded-xl border border-[#D8D5CE] bg-[#FAFAF8] px-3.5 py-2.5 text-sm text-[#141917] placeholder:text-[#78807C] focus:border-[#0F5C43] focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label
                    htmlFor="comment-location"
                    className="mb-1.5 block text-sm font-medium text-[#141917]"
                  >
                    শহর বা দেশ (ঐচ্ছিক)
                  </label>
                  <input
                    id="comment-location"
                    type="text"
                    maxLength={50}
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="যেমন: সৌদি আরব / দুবাই / ঢাকা"
                    className="min-h-[44px] w-full rounded-xl border border-[#D8D5CE] bg-[#FAFAF8] px-3.5 py-2.5 text-sm text-[#141917] placeholder:text-[#78807C] focus:border-[#0F5C43] focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label
                    htmlFor="comment-message"
                    className="mb-1.5 block text-sm font-medium text-[#141917]"
                  >
                    আপনার মন্তব্য <span className="text-[#C81E32]">*</span>
                  </label>
                  <textarea
                    id="comment-message"
                    rows={4}
                    maxLength={500}
                    required
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="আপনার অনুভূতি, পরামর্শ বা দোয়া লিখুন..."
                    className="w-full rounded-xl border border-[#D8D5CE] bg-[#FAFAF8] px-3.5 py-2.5 text-sm leading-relaxed text-[#141917] placeholder:text-[#78807C] focus:border-[#0F5C43] focus:bg-white focus:outline-none"
                  />
                  <div className="mt-1 text-right text-xs text-[#6B736F] tabular-nums">
                    {toBanglaDigits(message.length)} / {toBanglaDigits(500)}
                  </div>
                </div>

                {submitFeedback && (
                  <div
                    role="status"
                    className={`rounded-xl border px-3.5 py-2.5 text-sm ${
                      submitFeedback.type === 'success'
                        ? 'border-[#B8DEC9] bg-[#EEF7F2] text-[#0F5C43]'
                        : 'border-[#F3C2C7] bg-[#FDF2F3] text-[#9E1728]'
                    }`}
                  >
                    {submitFeedback.text}
                  </div>
                )}

                <button
                  type="submit"
                  className="inline-flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl bg-[#0F5C43] px-5 py-2.5 text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#0B4733] whitespace-nowrap"
                >
                  <Send className="h-4 w-4 shrink-0" />
                  <span>মন্তব্য প্রকাশ করুন</span>
                </button>
              </form>
            </div>
          </div>

          {/* Right: Comments Feed */}
          <div className="lg:col-span-7">
            <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-[#E6E4DF] pb-4">
              <h3 className="font-display text-xl font-bold text-[#141917]">
                সবার মন্তব্য ও শুভকামনা
              </h3>
              <span className="text-sm text-[#4A524E] tabular-nums">
                মোট মন্তব্য: {toBanglaDigits(comments.length)}টি
              </span>
            </div>

            {comments.length === 0 ? (
              <div className="mt-6 rounded-2xl border border-[#E6E4DF] bg-white p-8 text-center">
                <MessageSquareHeart
                  className="mx-auto h-8 w-8 text-[#0F5C43]"
                  aria-hidden="true"
                />
                <p className="mt-3 font-display text-base font-semibold text-[#141917]">
                  এখনো কোনো মন্তব্য নেই
                </p>
                <p className="mt-1 text-sm text-[#4A524E]">
                  প্রথম মন্তব্য বা দোয়াটি লিখে আমাদের উৎসাহিত করুন।
                </p>
              </div>
            ) : (
              <div className="divide-y divide-[#E6E4DF]">
                {comments.map((comment) => (
                  <article key={comment.id} className="py-5">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-[#616965]">
                      <span className="font-display text-sm font-semibold text-[#141917]">
                        {comment.authorName}
                      </span>
                      {comment.location && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{comment.location}</span>
                        </>
                      )}
                      <span aria-hidden="true">·</span>
                      <span>{formatBanglaDate(comment.createdAtIso)}</span>
                    </div>
                    <p className="mt-2 whitespace-pre-line text-[15px] leading-[1.7] text-[#2F3633]">
                      {comment.message}
                    </p>
                  </article>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
