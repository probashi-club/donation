import { useState } from 'react';
import { Minus, Plus } from 'lucide-react';
import { FAQ_ITEMS } from '../data/campaignContent';

export function FaqSection() {
  const [openId, setOpenId] = useState<number | null>(1);

  return (
    <section
      id="faq"
      className="border-t border-[#E6E4DF] bg-white py-16 md:py-24"
    >
      <div className="mx-auto max-w-4xl px-5 sm:px-8">
        <div className="mb-10 max-w-2xl">
          <p className="text-sm font-medium text-[#0F5C43]">
            স্বচ্ছতা ও সাধারণ জিজ্ঞাসা
          </p>
          <h2 className="mt-2 font-display text-2xl font-bold tracking-tight text-[#141917] sm:text-3xl text-balance">
            সচরাচর জিজ্ঞাসিত প্রশ্ন (FAQ)
          </h2>
          <p className="mt-3 text-base leading-relaxed text-[#4A524E]">
            আমাদের আবেদন, ব্যয়ের খাত এবং গোপনীয়তা নিয়ে আপনার মনে থাকা সম্ভাব্য
            সকল প্রশ্নের স্পষ্ট উত্তর নিচে দেওয়া হলো।
          </p>
        </div>

        <div className="divide-y divide-[#E6E4DF] border-y border-[#E6E4DF]">
          {FAQ_ITEMS.map((item) => {
            const isOpen = openId === item.id;
            return (
              <div key={item.id} className="py-1">
                <button
                  type="button"
                  aria-expanded={isOpen}
                  onClick={() => setOpenId(isOpen ? null : item.id)}
                  className="flex min-h-[52px] w-full items-center justify-between gap-4 py-4 text-left transition-colors duration-150 hover:text-[#0F5C43] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F5C43]"
                >
                  <span className="font-display text-base font-semibold leading-snug text-[#141917] sm:text-lg">
                    {item.question}
                  </span>
                  <span
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[#E6E4DF] bg-[#FAFAF8] text-[#141917]"
                    aria-hidden="true"
                  >
                    {isOpen ? (
                      <Minus className="h-4 w-4" />
                    ) : (
                      <Plus className="h-4 w-4" />
                    )}
                  </span>
                </button>
                {isOpen && (
                  <div className="pb-5 pr-8 text-[15px] leading-[1.8] text-[#4A524E] sm:text-base">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
