import { FormEvent, useEffect, useState } from 'react';
import { Check, CheckCircle2, Copy, HeartHandshake, X } from 'lucide-react';
import { CampaignConfig, DonationRecord } from '../data/campaignContent';
import { BkashLogo, NagadLogo } from './PaymentLogos';

interface DonationModalProps {
  open: boolean;
  onClose: () => void;
  campaign: CampaignConfig;
  onCommentAdded: (authorName: string, message: string) => void;
}

const DONATIONS_STORAGE_KEY = 'swapnojatra_donations_v1';

export function DonationModal({
  open,
  onClose,
  campaign,
  onCommentAdded,
}: DonationModalProps) {
  const [method, setMethod] = useState<'bkash' | 'nagad'>('bkash');
  const [trxId, setTrxId] = useState('');
  const [donorName, setDonorName] = useState('');
  const [message, setMessage] = useState('');
  const [shareAsComment, setShareAsComment] = useState(true);
  const [copiedField, setCopiedField] = useState<'bkash' | 'nagad' | 'summary' | null>(
    null,
  );
  const [submittedRecord, setSubmittedRecord] = useState<DonationRecord | null>(
    null,
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  if (!open) return null;

  async function copyText(
    type: 'bkash' | 'nagad' | 'summary',
    value: string,
  ) {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedField(type);
      setTimeout(() => setCopiedField(null), 2000);
    } catch {
      // Ignore if clipboard blocked
    }
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setErrorMsg(null);

    const cleanTrx = trxId.trim().slice(0, 40);
    const cleanName = (donorName.trim() || 'একজন শুভাকাঙ্ক্ষী').slice(0, 60);
    const cleanMessage = message.trim().slice(0, 300);

    if (cleanTrx.length < 3) {
      setErrorMsg('অনুগ্রহ করে সঠিক ট্রানজেকশন আইডি (TrxID) লিখুন।');
      return;
    }

    const record: DonationRecord = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      method,
      trxId: cleanTrx,
      donorName: cleanName,
      message: cleanMessage,
      createdAtIso: new Date().toISOString(),
    };

    try {
      const existingRaw = localStorage.getItem(DONATIONS_STORAGE_KEY);
      const existing: DonationRecord[] = existingRaw
        ? (JSON.parse(existingRaw) as DonationRecord[])
        : [];
      localStorage.setItem(
        DONATIONS_STORAGE_KEY,
        JSON.stringify([record, ...existing].slice(0, 50)),
      );
    } catch {
      // Ignore storage quota errors
    }

    if (shareAsComment && cleanMessage.length >= 2) {
      onCommentAdded(cleanName, cleanMessage);
    }

    setSubmittedRecord(record);
    setTrxId('');
    setDonorName('');
    setMessage('');
  }

  function resetAndClose() {
    setSubmittedRecord(null);
    setErrorMsg(null);
    onClose();
  }

  const formattedReceipt = submittedRecord
    ? `মাধ্যম: ${submittedRecord.method === 'bkash' ? 'বিকাশ' : 'নগদ'}\nTrxID: ${submittedRecord.trxId}\nনাম: ${submittedRecord.donorName}${
        submittedRecord.message ? `\nবার্তা: ${submittedRecord.message}` : ''
      }`
    : '';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="donation-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) resetAndClose();
      }}
    >
      <div className="relative max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-2xl border border-[#E6E4DF] bg-white p-5 sm:p-8">
        <div className="flex items-start justify-between gap-4 border-b border-[#E6E4DF] pb-4">
          <div>
            <h2
              id="donation-modal-title"
              className="font-display text-xl font-bold text-[#141917] sm:text-2xl"
            >
              সহযোগিতা পাঠানোর মাধ্যম
            </h2>
            <p className="mt-1 text-sm text-[#4A524E]">
              নিচের বিকাশ বা নগদ নাম্বারে সেন্ড মানি করার পর আপনার ট্রানজেকশন
              আইডি ও ছোট বার্তাটি লিখে দিতে পারেন।
            </p>
          </div>
          <button
            type="button"
            onClick={resetAndClose}
            aria-label="পপআপ বন্ধ করুন"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#E6E4DF] bg-[#FAFAF8] text-[#141917] transition-colors hover:bg-[#F0EFEA]"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {submittedRecord ? (
          <div className="py-8 text-center">
            <CheckCircle2
              className="mx-auto h-12 w-12 text-[#0F5C43]"
              aria-hidden="true"
            />
            <h3 className="mt-4 font-display text-2xl font-bold text-[#141917]">
              অসংখ্য ধন্যবাদ ও কৃতজ্ঞতা!
            </h3>
            <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-[#4A524E]">
              আপনার সহযোগিতা ও দোয়ার জন্য আমরা চিরকৃতজ্ঞ। নিচের তথ্যটি সংরক্ষণ
              বা শেয়ার করতে চাইলে কপি করে নিতে পারেন।
            </p>

            <div className="mx-auto mt-5 max-w-md rounded-xl border border-[#E6E4DF] bg-[#FAFAF8] p-4 text-left text-xs leading-relaxed text-[#2F3633]">
              <p>
                <span className="font-semibold text-[#141917]">মাধ্যম:</span>{' '}
                {submittedRecord.method === 'bkash' ? 'বিকাশ' : 'নগদ'}
              </p>
              <p className="mt-1 font-mono">
                <span className="font-sans font-semibold text-[#141917]">
                  TrxID:
                </span>{' '}
                {submittedRecord.trxId}
              </p>
              <p className="mt-1">
                <span className="font-semibold text-[#141917]">নাম:</span>{' '}
                {submittedRecord.donorName}
              </p>
              {submittedRecord.message && (
                <p className="mt-1">
                  <span className="font-semibold text-[#141917]">বার্তা:</span>{' '}
                  {submittedRecord.message}
                </p>
              )}
            </div>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => void copyText('summary', formattedReceipt)}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-[#D8D5CE] bg-white px-4 py-2.5 text-sm font-medium text-[#141917] transition-colors hover:bg-[#FAFAF8] whitespace-nowrap"
              >
                {copiedField === 'summary' ? (
                  <>
                    <Check className="h-4 w-4 text-[#0F5C43]" />
                    <span>তথ্য কপি হয়েছে</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4" />
                    <span>তথ্য কপি করুন</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={() => setSubmittedRecord(null)}
                className="min-h-[44px] rounded-xl border border-[#D8D5CE] bg-white px-5 py-2.5 text-sm font-medium text-[#141917] transition-colors hover:bg-[#FAFAF8] whitespace-nowrap"
              >
                আরেকটি তথ্য দিন
              </button>
              <button
                type="button"
                onClick={resetAndClose}
                className="min-h-[44px] rounded-xl bg-[#0F5C43] px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#0B4733] whitespace-nowrap"
              >
                সম্পন্ন করুন
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-5 space-y-6">
            {/* Payment Channel Cards */}
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {/* bKash Card */}
              <div className="flex flex-col justify-between rounded-xl border border-[#F2C6D9] bg-[#FFF8FB] p-4">
                <div className="flex items-center justify-between gap-2">
                  <BkashLogo />
                  <span className="text-xs font-medium text-[#8C1D4F]">
                    {campaign.bkashLabel}
                  </span>
                </div>
                <div className="mt-4 flex items-center justify-between gap-2 rounded-lg border border-[#F2D5E2] bg-white px-3 py-2">
                  <span className="font-mono text-base font-semibold tracking-tight text-[#141917] tabular-nums">
                    {campaign.bkashNumber}
                  </span>
                  <button
                    type="button"
                    onClick={() => void copyText('bkash', campaign.bkashNumber)}
                    className="inline-flex min-h-[34px] items-center gap-1 rounded-lg bg-[#E2136E] px-2.5 py-1 text-xs font-semibold text-white transition-colors hover:bg-[#C10F5D] whitespace-nowrap shrink-0"
                  >
                    {copiedField === 'bkash' ? (
                      <>
                        <Check className="h-3.5 w-3.5" />
                        <span>কপি হয়েছে</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        <span>কপি</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Nagad Card */}
              <div className="flex flex-col justify-between rounded-xl border border-[#FAD6C3] bg-[#FFF9F5] p-4">
                <div className="flex items-center justify-between gap-2">
                  <NagadLogo />
                  <span className="text-xs font-medium text-[#9A380B]">
                    {campaign.nagadLabel}
                  </span>
                </div>
                <div className="mt-4 flex items-center justify-between gap-2 rounded-lg border border-[#F5DDD0] bg-white px-3 py-2">
                  <span className="font-mono text-base font-semibold tracking-tight text-[#141917] tabular-nums">
                    {campaign.nagadNumber}
                  </span>
                  <button
                    type="button"
                    onClick={() => void copyText('nagad', campaign.nagadNumber)}
                    className="inline-flex min-h-[34px] items-center gap-1 rounded-lg bg-[#D94E14] px-2.5 py-1 text-xs font-semibold text-white transition-colors hover:bg-[#B8400E] whitespace-nowrap shrink-0"
                  >
                    {copiedField === 'nagad' ? (
                      <>
                        <Check className="h-3.5 w-3.5" />
                        <span>কপি হয়েছে</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        <span>কপি</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            <p className="text-xs leading-relaxed text-[#4A524E]">
              আপনার সামর্থ্য অনুযায়ী ৫০, ১০০, ২০০ কিংবা ৫০০ টাকা—যেকোনো পরিমাণ
              সহযোগিতাই আমাদের জন্য অনেক বড় শক্তি। অনুগ্রহ করে সেন্ড মানি করার পর
              নিচের ফর্মটি পূরণ করুন।
            </p>

            {/* Transaction Confirmation Form */}
            <form
              onSubmit={handleSubmit}
              className="space-y-4 border-t border-[#E6E4DF] pt-5"
            >
              <div>
                <span className="mb-2 block text-sm font-medium text-[#141917]">
                  কোন মাধ্যমে পাঠিয়েছেন?
                </span>
                <div className="grid grid-cols-2 gap-2 rounded-xl bg-[#F3F1EC] p-1">
                  <button
                    type="button"
                    onClick={() => setMethod('bkash')}
                    className={`min-h-[42px] rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${
                      method === 'bkash'
                        ? 'bg-white text-[#E2136E] shadow-sm'
                        : 'text-[#4A524E] hover:text-[#141917]'
                    }`}
                  >
                    বিকাশ (bKash)
                  </button>
                  <button
                    type="button"
                    onClick={() => setMethod('nagad')}
                    className={`min-h-[42px] rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${
                      method === 'nagad'
                        ? 'bg-white text-[#D94E14] shadow-sm'
                        : 'text-[#4A524E] hover:text-[#141917]'
                    }`}
                  >
                    নগদ (Nagad)
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="trx-id"
                    className="mb-1.5 block text-sm font-medium text-[#141917]"
                  >
                    ট্রানজেকশন আইডি (TrxID){' '}
                    <span className="text-[#C81E32]">*</span>
                  </label>
                  <input
                    id="trx-id"
                    type="text"
                    required
                    maxLength={40}
                    value={trxId}
                    onChange={(e) => setTrxId(e.target.value)}
                    placeholder="যেমন: BJK78H92KL"
                    className="min-h-[44px] w-full rounded-xl border border-[#D8D5CE] bg-[#FAFAF8] px-3.5 py-2.5 font-mono text-sm text-[#141917] placeholder:font-sans placeholder:text-[#78807C] focus:border-[#0F5C43] focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label
                    htmlFor="donor-name"
                    className="mb-1.5 block text-sm font-medium text-[#141917]"
                  >
                    আপনার নাম (ঐচ্ছিক)
                  </label>
                  <input
                    id="donor-name"
                    type="text"
                    maxLength={60}
                    value={donorName}
                    onChange={(e) => setDonorName(e.target.value)}
                    placeholder="নাম না দিলে শুভাকাঙ্ক্ষী থাকবে"
                    className="min-h-[44px] w-full rounded-xl border border-[#D8D5CE] bg-[#FAFAF8] px-3.5 py-2.5 text-sm text-[#141917] placeholder:text-[#78807C] focus:border-[#0F5C43] focus:bg-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="donor-message"
                  className="mb-1.5 block text-sm font-medium text-[#141917]"
                >
                  ছোট ম্যাসেজ বা দোয়া (ঐচ্ছিক)
                </label>
                <textarea
                  id="donor-message"
                  rows={2}
                  maxLength={300}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="আমাদের জন্য কোনো দোয়া বা পরামর্শ লিখতে পারেন..."
                  className="w-full rounded-xl border border-[#D8D5CE] bg-[#FAFAF8] px-3.5 py-2.5 text-sm text-[#141917] placeholder:text-[#78807C] focus:border-[#0F5C43] focus:bg-white focus:outline-none"
                />
              </div>

              {message.trim().length >= 2 && (
                <label className="flex cursor-pointer items-start gap-2.5 text-xs text-[#4A524E]">
                  <input
                    type="checkbox"
                    checked={shareAsComment}
                    onChange={(e) => setShareAsComment(e.target.checked)}
                    className="mt-0.5 h-4 w-4 rounded border-[#D8D5CE] text-[#0F5C43] focus:ring-[#0F5C43]"
                  />
                  <span>
                    আমার নাম ও ছোট বার্তাটি নিচের মন্তব্য সেকশনে দেখান
                    (ট্রানজেকশন আইডি গোপন থাকবে)
                  </span>
                </label>
              )}

              {errorMsg && (
                <div
                  role="alert"
                  className="rounded-xl border border-[#F3C2C7] bg-[#FDF2F3] px-3.5 py-2.5 text-sm text-[#9E1728]"
                >
                  {errorMsg}
                </div>
              )}

              <button
                type="submit"
                className="inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-[#0F5C43] px-6 py-3 text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#0B4733] whitespace-nowrap"
              >
                <HeartHandshake className="h-4 w-4 shrink-0" />
                <span>ট্রানজেকশন তথ্য জমা দিন</span>
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
